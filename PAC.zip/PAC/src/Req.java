/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class Req {
    private int r_id,e_id,r_money;
    private String r_matrials,r_volunteers;
    
    public Req(int e_id,int r_id,int r_money,String r_matrials,String r_volunteers)
    {
        this.e_id=e_id;
        this.r_id=r_id;
        this.r_money=r_money;
        this.r_matrials=r_matrials;
        this.r_volunteers=r_volunteers;
        
    }
    public int gete_id()
    {
        return e_id;
    }
     public int getr_id()
    {
        return r_id;
    }
      public int getr_money()
    {
        return r_money;
    }
       public String getr_matrials()
    {
        return r_matrials;
    }
        public String getr_volunteers()
    {
        return r_volunteers;
    }
}
