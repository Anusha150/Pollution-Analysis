/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class FB {
        private int f_id,u_id;
    private String f_pollution,f_description;
    
    public FB(int f_id,int u_id,String f_pollution,String f_description)
    {
        this.f_id=f_id;
        this.u_id=u_id;
        this.f_pollution=f_pollution;
        this.f_description=f_description;
        
    }
    public int getf_id()
    {
        return f_id;
    }
     public int getu_id()
    {
        return u_id;
    }
        public String getf_pollution()
    {
        return f_pollution;
    }
        public String getf_description()
    {
        return f_description;
    }
    
    
}
