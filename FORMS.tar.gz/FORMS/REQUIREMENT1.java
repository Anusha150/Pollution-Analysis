 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="REQUIREMENT1" width=540 height=500>  

 </applet>  

 */  

public class REQUIREMENT1 extends Applet implements ActionListener
{
	TextField r_id,r_money ,r_matrials,r_volunteers ,e_id ;
	Label l,l1,l2,l3,l4,l5;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("REQUIRMENT");
		l1=new Label("Reqr id:");
		l2=new Label("Reqr Money:");
		l3=new Label("Reqr Mtrl:");
		l4=new Label("Reqr Vol:");
		l5=new Label("Event id:");

		//l1.setText("Requirement id:");
		

		r_id=new TextField(40);
		r_money=new TextField(40);
		r_matrials=new TextField(40);
		r_volunteers=new TextField(40);
		e_id=new TextField(40);


		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
	
	

		add(r_id);
		add(r_money);
		add(r_matrials);
		add(r_volunteers);
		add(e_id);
		


		add(b1);
		add(b2);
		
		l.setBounds(150,20,220,40);
		l1.setBounds(20,90,220,30);
		l2.setBounds(20,150,220,30);
		l3.setBounds(20,210,220,30);
		l4.setBounds(20,270,220,30);
		l5.setBounds(20,330,220,30);

		r_id.setBounds(280,80,200,40);
		r_money.setBounds(280,140,200,40);
		r_matrials.setBounds(280,200,200,40);
		r_volunteers.setBounds(280,260,200,40);
		e_id.setBounds(280,320,200,40);
	

		b1.setBounds(100,400,100,40);
		b2.setBounds(250,400,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
		         g.setColor(Color.gray);
                         g.fillRect(10,10,500,480);
		
	}


}
