 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="LOGIN1" width=425 height=300>  

 </applet>  
 */  

public class LOGIN1 extends Applet implements ActionListener
{
	TextField u_username,u_password;
	Label l,l1,l2;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("LOGIN");
		l1=new Label("Username:");
		l2=new Label("Password:");

		u_username=new TextField(40);
		u_password=new TextField(40);

		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
	
		add(u_username);
		add(u_password);

		add(b1);
		add(b2);
		
		l.setBounds(150,20,100,40);
		l1.setBounds(20,90,100,20);
		l2.setBounds(20,150,100,20);

		u_username.setBounds(200,80,200,40);
		u_password.setBounds(200,140,200,40);

		b1.setBounds(100,220,100,40);
		b2.setBounds(250,220,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
			 g.setColor(Color.gray);
                         g.fillRect(10,10,400,320);
		
	}


}
