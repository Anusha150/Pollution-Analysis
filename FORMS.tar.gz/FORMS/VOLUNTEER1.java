 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="VOLUNTEER1" width=425 height=300>  

 </applet>  
 */  

public class VOLUNTEER1 extends Applet implements ActionListener
{
	TextField u_id,e_id;
	Label l,l1,l2;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("VOLUNTEER");
		l1=new Label("User Id:");
		l2=new Label("Event Id:");

		u_id=new TextField(40);
		e_id=new TextField(40);

		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
	
		add(u_id);
		add(e_id);

		add(b1);
		add(b2);
		
		l.setBounds(150,20,100,40);
		l1.setBounds(20,90,100,20);
		l2.setBounds(20,150,100,20);

		u_id.setBounds(200,80,200,40);
		e_id.setBounds(200,140,200,40);

		b1.setBounds(100,220,100,40);
		b2.setBounds(250,220,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
			 g.setColor(Color.gray);
                         g.fillRect(10,10,400,320);
		
	}


}
