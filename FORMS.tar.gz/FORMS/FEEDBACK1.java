 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="FEEDBACK1" width=420 height=400>  

 </applet>  

 */  

public class FEEDBACK1 extends Applet implements ActionListener
{
	TextField f_id,f_pollution ,f_description,u_id;
	Label l,l1,l2,l3,l4;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("FEEDBACK");
		l1=new Label("Feedback id:");
		l2=new Label("Feed Poll:");
		l3=new Label("Feed desc:");
		l4=new Label("user id:");


		f_id=new TextField(40);
		f_pollution=new TextField(40);
	        f_description=new TextField(40);
		u_id=new TextField(40);


		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
	
	

		add(f_id);
		add(f_pollution);
		add(f_description);
		add(u_id);


		add(b1);
		add(b2);
		
		l.setBounds(150,20,100,40);
		l1.setBounds(20,90,100,30);
		l2.setBounds(20,150,100,30);
		l3.setBounds(20,210,100,30);
		l4.setBounds(20,270,100,30);

		f_id.setBounds(200,80,200,40);
		f_pollution.setBounds(200,140,200,40);
		f_description.setBounds(200,200,200,40);
		u_id.setBounds(200,260,200,40);
	

		b1.setBounds(100,350,100,40);
		b2.setBounds(250,350,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
		         g.setColor(Color.gray);
                         g.fillRect(10,10,400,400);
		
	}


}
