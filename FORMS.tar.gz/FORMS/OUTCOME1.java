 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="OUTCOME1" width=420 height=400>  

 </applet>  

 */  

public class OUTCOME1 extends Applet implements ActionListener
{
	TextField o_id,o_pollution,o_status,o_description;
	Label l,l1,l2,l3,l4;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("OUTCOME");
		l1=new Label("Outcome id:");
		l2=new Label("Out type:");
		l3=new Label("Out Status:");
		l4=new Label("Out desc:");


		o_id=new TextField(40);
		o_pollution=new TextField(40);
	        o_status=new TextField(40);
		o_description=new TextField(40);


		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
	
	

		add(o_id);
		add(o_pollution);
		add(o_status);
		add(o_description);


		add(b1);
		add(b2);
		
		l.setBounds(150,20,100,40);
		l1.setBounds(20,90,100,30);
		l2.setBounds(20,150,100,30);
		l3.setBounds(20,210,100,30);
		l4.setBounds(20,270,100,30);

		o_id.setBounds(200,80,200,40);
		o_pollution.setBounds(200,140,200,40);
		o_status.setBounds(200,200,200,40);
		o_description.setBounds(200,260,200,40);
	

		b1.setBounds(100,350,100,40);
		b2.setBounds(250,350,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
		         g.setColor(Color.gray);
                         g.fillRect(10,10,400,400);
		
	}


}
