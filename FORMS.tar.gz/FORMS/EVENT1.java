 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="EVENT1" width=420 height=550>  

 </applet>  

 */  

public class EVENT1 extends Applet implements ActionListener
{
	TextField e_id,e_name,e_pollution,e_place ,e_date,p_id,a_id;
//	TextArea t4;
	Label l,l1,l2,l3,l4,l5,l6,l7;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("EVENT");
		l1=new Label("Event Id:");
		l2=new Label("Event Name:");
		l3=new Label("Poll Type");
		l4=new Label("Event Place:");
		l5=new Label("Event Date:");
		l6=new Label("Poll id:");
		l7=new Label("Admin Id:");

		e_id=new TextField(40);
		e_name=new TextField(40);
		e_pollution=new TextField(40);
		e_place=new TextField(40);
	//	t4=new TextArea();
		e_date=new TextField(40);
		p_id=new TextField(40);
		a_id=new TextField(40);

		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
		add(l6);
		add(l7);
	

		add(e_id);
		add(e_name);
		add(e_pollution);
		add(e_place);
		add(e_date);
		add(p_id);
		add(a_id);

		add(b1);
		add(b2);
		
		l.setBounds(150,20,100,40);
		l1.setBounds(20,90,100,30);
		l2.setBounds(20,150,100,30);
		l3.setBounds(20,210,100,30);
		l4.setBounds(20,270,100,30);
		l5.setBounds(20,330,100,30);
		l6.setBounds(20,390,100,30);
		l7.setBounds(20,450,100,30);

		e_id.setBounds(200,80,200,40);
		e_name.setBounds(200,140,200,40);
		e_pollution.setBounds(200,200,200,40);
		e_place.setBounds(200,260,200,40);
		e_date.setBounds(200,320,200,40);
		p_id.setBounds(200,380,200,40);
		a_id.setBounds(200,440,200,40);

		b1.setBounds(100,500,100,40);
		b2.setBounds(250,500,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
		         g.setColor(Color.gray);
                         g.fillRect(10,10,400,550);
		
	}


}
