 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="SPONSOR1" width=425 height=330>  

 </applet>  
 */  

public class SPONSOR1 extends Applet implements ActionListener
{
	TextField u_id,e_id,amt;
	Label l,l1,l2,l3;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("SPONSOR");
		l1=new Label("User Id:");
		l2=new Label("Event Id:");
		l3=new Label("Amount:");

		u_id=new TextField(40);
		e_id=new TextField(40);
		amt=new TextField(40);

		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
		add(l3);
	
		add(u_id);
		add(e_id);
		add(amt);

		add(b1);
		add(b2);
		
		l.setBounds(150,20,100,40);
		l1.setBounds(20,90,100,20);
		l2.setBounds(20,150,100,20);
		l3.setBounds(20,210,100,20);

		u_id.setBounds(200,80,200,40);
		e_id.setBounds(200,140,200,40);
		amt.setBounds(200,200,200,40);

		b1.setBounds(100,260,100,40);
		b2.setBounds(250,260,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
			 g.setColor(Color.gray);
                         g.fillRect(10,10,400,320);
		
	}


}
