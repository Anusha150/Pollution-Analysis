 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="PROBLEM1" width=540 height=500>  

 </applet>  

 */  

public class PROBLEM1 extends Applet implements ActionListener
{
	TextField p_id,p_pollution ,p_place,p_description,u_id ;
	Label l,l1,l2,l3,l4,l5;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("PROBLEM REPORT");
		l1=new Label("Problem Id:");
		l2=new Label("Poll type:");
		l3=new Label("Poll place:");
		l4=new Label("Pollution Desc:");
		l5=new Label("User id:");

		p_id=new TextField(40);
		p_pollution=new TextField(40);
		p_place=new TextField(40);
		p_description=new TextField(40);
		u_id=new TextField(40);


		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
	
	

		add(p_id);
		add(p_pollution);
		add(p_place);
		add(p_description);
		add(u_id);
		


		add(b1);
		add(b2);
		
		l.setBounds(150,20,180,40);
		l1.setBounds(20,90,180,20);
		l2.setBounds(20,150,180,20);
		l3.setBounds(20,210,180,20);
		l4.setBounds(20,270,180,20);
		l5.setBounds(20,330,180,20);

		p_id.setBounds(280,80,200,40);
		p_pollution.setBounds(280,140,200,40);
		p_place.setBounds(280,200,200,40);
		p_description.setBounds(280,260,200,40);
		u_id.setBounds(280,320,200,40);
	

		b1.setBounds(100,400,100,40);
		b2.setBounds(250,400,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
		         g.setColor(Color.gray);
                         g.fillRect(10,10,500,480);
		
	}


}
