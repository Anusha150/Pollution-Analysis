 import java.awt.*;  

 import java.awt.event.*;  

 import java.applet.*;  

 /*  

 <applet code="IDEA1" width=420 height=400>  

 </applet>  

 */  

public class IDEA1 extends Applet implements ActionListener
{
	TextField i_id,i_pollution,i_description ,u_id;
	Label l,l1,l2,l3,l4;
	Button b1,b2;
	public void init()
	{
		setLayout(null);
		
		l=new Label("IDEA");
		l1=new Label("Idea Id:");
		l2=new Label("Idea type:");
		l3=new Label("Idea desci:");
		l4=new Label("User id:");


		i_id=new TextField(40);
		i_pollution=new TextField(40);
		i_description=new TextField(40);
		u_id=new TextField(40);


		b1=new Button("Cancel");
		b2=new Button("Submit");


		add(l);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
	
	

		add(i_id);
		add(i_pollution);
		add(i_description);
		add(u_id);


		add(b1);
		add(b2);
		
		l.setBounds(150,20,100,40);
		l1.setBounds(20,90,100,30);
		l2.setBounds(20,150,100,30);
		l3.setBounds(20,210,170,30);
		l4.setBounds(20,270,100,30);

		i_id.setBounds(200,80,200,40);
		i_pollution.setBounds(200,140,200,40);
		i_description.setBounds(200,200,200,40);
		u_id.setBounds(200,260,200,40);
	

		b1.setBounds(100,350,100,40);
		b2.setBounds(250,350,100,40);
	}
	public void actionPerformed(ActionEvent e)
	{
		String str=e.getActionCommand();

	}

	public void paint(Graphics g)
	{
		         g.setColor(Color.gray);
                         g.fillRect(10,10,400,400);
		
	}


}
